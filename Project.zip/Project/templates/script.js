function navigateToDashboard() {
    window.location.href = "dashboard.html";
  }
  
  function navigateToStory() {
    window.location.href = "story.html";
  }
  
  function navigateToReport() {
    window.location.href = "report.html";
  }
  